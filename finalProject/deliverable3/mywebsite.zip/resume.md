![sheldoncooper](images.jpeg)
# Sheldon Cooper
Pasadena, California 12345 ◆ 213-123-4567 ◆ sheldoncooper@gmail.com
## Professional Summary
Exceptional researcher with solid physics foundation, ability to conceptualize complex geometrical and theoretical physics topics.

## Work History
**Theoretical Physicist**, 01/2004 to Current *CalTech - Pasadena California*
* Studying cosmic properties with calculus principles.
* Eating a ham sandwich on my lunch break.
* Discuss phenomena with pencil and paper

**Lemonade Stand**, 06/1992 to 08/1992 *Front Lawn - Texas*
* Sell freshly-made lemonade to bystanders.
* Distribute earns to coworkers.
* Handle public relations and satisfy customer needs.

## Skills
| Technical       | Communications          |
| --------------- | ----------------------- |
| Quantum Physics | Complaint resolution    |
| Matlab          | Technical Presentations |
## Education
| Degree            | School                             | Year |
| ----------------- | ---------------------------------- | ---- |
| Associates Degree | East Texas Tech                    | 2004 |
| Bachelors Degree  | California Institute of Technology | 2006 |
